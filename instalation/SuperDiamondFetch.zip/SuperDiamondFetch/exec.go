package main

import (
	"fmt"
	"os/exec"
)

func main() {
	fmt.Println("Starting SuperDiamondFetch...")

	for i := 3; i > 0; i-- {
		fmt.Printf("Something Went Wrong. Retrying. %d\n", i)
		cmd := exec.Command("php", "-S", "localhost:4001")
		if err := cmd.Run(); err != nil {
			fmt.Println("Failed to start PHP server:", err)
		}
	}

	fmt.Println("Failed Too Many Times. Going To Failed Dialogue...")
	fmt.Println("OOPS! Something went Wrong! Make sure you have php installed and commands can be executed with php.")
	fmt.Println("Make Sure path to php.exe is listed below. if it isn't, then we can't run php commands to start the app.")
	fmt.Println("If php.exe is listed above me, and this still doesn't work, please check the second lines above for any errors. You may try again as this may be a one-time issue.")
	fmt.Println("We Are Pausing The Script so you can read the things above me.")
	fmt.Println("Press Enter To Exit")
	fmt.Scanln()
}

const { execSync } = require('child_process');
const readline = require('readline');

// Starting SuperDiamondFetch...
console.log("Starting SuperDiamondFetch...");

// Starting PHP server
try {
    console.log(execSync("php -S localhost:4001"));
} catch (error) {
    console.error("Error starting PHP server:", error);
}

// Retrying if something went wrong
for (let i = 3; i >= 1; i--) {
    console.log(`Something Went Wrong. Retrying. ${i}`);
    try {
        execSync("php -S localhost:4001");
    } catch (error) {
        console.error("Error retrying PHP server:", error);
    }
}

// Failed dialogue
console.log("Failed Too Many Times. Going To Failed Dialogue...");
console.log("OOPS! Something went Wrong! Make sure you have php installed. and commands can be executed with php.");
console.log("Make Sure path to php.exe is listed below. if it isnt. then we cant run php commands to start the app.");
console.log(process.env.PATH);
console.log("If php.exe is listed above me. and this still dosent work. please check the second lines above for any errors. you may try again as this may be a one-time issue");
console.log("We Are Pausing The Script so you can read the things above me.");

// Wait for user input to exit
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question('Press Enter To Exit', (answer) => {
  rl.close();
});

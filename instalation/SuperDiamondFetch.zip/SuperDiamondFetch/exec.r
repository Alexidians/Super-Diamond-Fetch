# Starting SuperDiamondFetch...
cat("Starting SuperDiamondFetch...\n")

# Retry the PHP server command 3 times
for (i in 3:1) {
  cat(sprintf("Something Went Wrong. Retrying. %d\n", i))
  system("php -S localhost:4001")
}

# Display error messages and wait for user input
cat("Failed Too Many Times. Going To Failed Dialogue...\n")
cat("OOPS! Something went Wrong! Make sure you have php installed and commands can be executed with php.\n")
cat("Make Sure path to php.exe is listed below. if it isn't, then we can't run php commands to start the app.\n")
cat("If php.exe is listed above me, and this still doesn't work, please check the second lines above for any errors. You may try again as this may be a one-time issue.\n")
cat("We Are Pausing The Script so you can read the things above me.\n")
cat("Press Enter To Exit\n")
readLines("stdin", n=1)

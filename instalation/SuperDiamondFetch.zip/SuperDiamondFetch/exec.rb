# Starting SuperDiamondFetch...
puts "Starting SuperDiamondFetch..."

# Starting PHP server
begin
    system("php -S localhost:4001")
rescue => e
    puts "Error starting PHP server: #{e}"
end

# Retrying if something went wrong
3.downto(1) do |i|
    puts "Something Went Wrong. Retrying. #{i}"
    begin
        system("php -S localhost:4001")
    rescue => e
        puts "Error retrying PHP server: #{e}"
    end
end

# Failed dialogue
puts "Failed Too Many Times. Going To Failed Dialogue..."
puts "OOPS! Something went Wrong! Make sure you have php installed. and commands can be executed with php."
puts "Make Sure path to php.exe is listed below. if it isnt. then we cant run php commands to start the app."
puts `echo $PATH`
puts "If php.exe is listed above me. and this still dosent work. please check the second lines above for any errors. you may try again as this may be a one-time issue"
puts "We Are Pausing The Script so you can read the things above me."
print "Press Enter To Exit"
gets

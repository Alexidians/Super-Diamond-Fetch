-- Starting SuperDiamondFetch...
print("Starting SuperDiamondFetch...")

-- Retry the PHP server command 3 times
for i = 3, 1, -1 do
  print("Something Went Wrong. Retrying.", i)
  os.execute("php -S localhost:4001")
end

-- Display error messages and wait for user input
print("Failed Too Many Times. Going To Failed Dialogue...")
print("OOPS! Something went Wrong! Make sure you have php installed and commands can be executed with php.")
print("Make Sure path to php.exe is listed below. if it isn't, then we can't run php commands to start the app.")
print("If php.exe is listed above me, and this still doesn't work, please check the second lines above for any errors. You may try again as this may be a one-time issue.")
print("We Are Pausing The Script so you can read the things above me.")
io.read()  -- Wait for user input

import Foundation

// Starting SuperDiamondFetch...
print("Starting SuperDiamondFetch...")

// Retry the PHP server command 3 times
for i in (1...3).reversed() {
    print("Something Went Wrong. Retrying. \(i)")
    let task = Process()
    task.executableURL = URL(fileURLWithPath: "/usr/bin/php")
    task.arguments = ["-S", "localhost:4001"]
    do {
        try task.run()
    } catch {
        print("Failed to start PHP server:", error)
    }
}

// Display error messages and wait for user input
print("Failed Too Many Times. Going To Failed Dialogue...")
print("OOPS! Something went Wrong! Make sure you have php installed and commands can be executed with php.")
print("Make Sure path to php.exe is listed below. if it isn't, then we can't run php commands to start the app.")
print("If php.exe is listed above me, and this still doesn't work, please check the second lines above for any errors. You may try again as this may be a one-time issue.")
print("We Are Pausing The Script so you can read the things above me.")
_ = readLine()

#!/bin/bash

echo "Starting SuperDiamondFetch..."
php -S localhost:4001

echo "Something Went Wrong. Retrying. 3"
php -S localhost:4001

echo "Something Went Wrong. Retrying. 2"
php -S localhost:4001

echo "Something Went Wrong. Retrying. 1"
php -S localhost:4001

echo "Failed Too Many Times. Going To Failed Dialogue..."
echo "OOPS! Something went Wrong! Make sure you have php installed. and commands can be executed with php."
echo "Make Sure path to php.exe is listed below. if it isnt. then we cant run php commands to start the app."
echo "$PATH"
echo "If php.exe is listed above me. and this still dosent work. please check the second lines above for any errors. you may try again as this may be a one-time issue"
echo "We Are Pausing The Script so you can read the things above me."
read -p "Press Enter To Exit"
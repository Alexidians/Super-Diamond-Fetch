#!/usr/bin/perl

use strict;
use warnings;

# Starting SuperDiamondFetch...
print "Starting SuperDiamondFetch...\n";

# Starting PHP server
system("php -S localhost:4001");

# Retrying if something went wrong
for my $i (3, 2, 1) {
    print "Something Went Wrong. Retrying. $i\n";
    system("php -S localhost:4001");
}

# Failed dialogue
print "Failed Too Many Times. Going To Failed Dialogue...\n";
print "OOPS! Something went Wrong! Make sure you have php installed. and commands can be executed with php.\n";
print "Make Sure path to php.exe is listed below. if it isnt. then we cant run php commands to start the app.\n";
print "$ENV{PATH}\n";
print "If php.exe is listed above me. and this still dosent work. please check the second lines above for any errors. you may try again as this may be a one-time issue\n";
print "We Are Pausing The Script so you can read the things above me.\n";
print "Press Enter To Exit\n";
<STDIN>;
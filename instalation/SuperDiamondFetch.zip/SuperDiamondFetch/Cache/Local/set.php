<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

$Data = json_decode(file_get_contents("php://input"), true);
$cache = json_decode(file_get_contents("cache/cache.json"), true);
$cache[$Data["key"]] = $Data["value"];
file_put_contents("cache/cache.json", json_encode($cache));
?>

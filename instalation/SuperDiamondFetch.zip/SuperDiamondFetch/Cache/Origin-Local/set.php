<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

$Data = json_decode(file_get_contents("php://input"), true);
$cache = json_decode(file_get_contents("cache/" . parse_url($_SERVER["HTTP_ORIGIN"])["scheme"] . "/" . parse_url($_SERVER["HTTP_ORIGIN"])["host"]), true);
$cache[$Data["key"]] = $Data["value"];
file_put_contents("cache/" . parse_url($_SERVER["HTTP_ORIGIN"])["scheme"] . "/" . parse_url($_SERVER["HTTP_ORIGIN"])["host"], json_encode($cache));
?>

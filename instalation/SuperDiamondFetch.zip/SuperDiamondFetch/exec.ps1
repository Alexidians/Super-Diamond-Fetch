# Starting SuperDiamondFetch...
Write-Output "Starting SuperDiamondFetch..."

# Starting PHP server
$command = "php -S localhost:4001"
Invoke-Expression $command

# Retrying if something went wrong
for ($i = 3; $i -ge 1; $i--) {
    Write-Output "Something Went Wrong. Retrying. $i"
    Invoke-Expression $command
}

# Failed dialogue
Write-Output "Failed Too Many Times. Going To Failed Dialogue..."
Write-Output "OOPS! Something went Wrong! Make sure you have php installed. and commands can be executed with php."
Write-Output "Make Sure path to php.exe is listed below. if it isnt. then we cant run php commands to start the app."
Write-Output "$env:PATH"
Write-Output "If php.exe is listed above me. and this still dosent work. please check the second lines above for any errors. you may try again as this may be a one-time issue"
Write-Output "We Are Pausing The Script so you can read the things above me."
Write-Output "Press Enter To Exit"
Read-Host

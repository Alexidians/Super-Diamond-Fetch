import subprocess

# Starting SuperDiamondFetch...
print("Starting SuperDiamondFetch...")

# Starting PHP server
try:
    subprocess.run(["php", "-S", "localhost:4001"], check=True)
except subprocess.CalledProcessError as e:
    print("Error starting PHP server:", e)

# Retrying if something went wrong
for i in range(3, 0, -1):
    print(f"Something Went Wrong. Retrying. {i}")
    try:
        subprocess.run(["php", "-S", "localhost:4001"], check=True)
    except subprocess.CalledProcessError as e:
        print("Error retrying PHP server:", e)

# Failed dialogue
print("Failed Too Many Times. Going To Failed Dialogue...")
print("OOPS! Something went Wrong! Make sure you have php installed. and commands can be executed with php.")
print("Make Sure path to php.exe is listed below. if it isnt. then we cant run php commands to start the app.")
print(subprocess.run(["echo", "$PATH"], capture_output=True, text=True).stdout)
print("If php.exe is listed above me. and this still dosent work. please check the second lines above for any errors. you may try again as this may be a one-time issue")
print("We Are Pausing The Script so you can read the things above me.")
input("Press Enter To Exit")